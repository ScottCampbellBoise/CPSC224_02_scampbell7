public interface TwoDShape extends GeometricShape {
    public double area();
}
